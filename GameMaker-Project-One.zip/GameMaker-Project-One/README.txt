﻿Sweet Escape!
A Game by Aadya Maurya & Samantha Mroz


Controls:
* Left, Right, Up, Down: Basic Movement
* (Hold) E: Grab Blocks
* E: Open Exit Door
* F: Swing Weapon


Walkthrough:
1. Tutorial
   1. In the first room, push the block onto the button to open the door.
   2. In the second room, use the platforms to get to the block. Push it onto the button to open the door.
   3. In the third room, grab the candy corn weapon. Press F near the enemy to be able to get by.
   4. Continue until the floor opens up, and jump down to begin the game!
2. Main Level
   1. In the original cell, stack the available blocks to make a tower. With at least 3 blocks stacked, you are able to jump out of the hole in the ceiling.
   2. Locate the block to the far left of the map. Escort this block to the lowest level cell on the bottom left corner of the map, and leave it on the button.
   3. The door to the adjacent cell to the right should be open. Inside, find the candy corn weapon.
   4. Now, travelling to the right side of the map, find the stack of two blocks. Platform upwards into the cell with a hole in its floor. Use the weapon on the guard blocking your way upwards.
   5. Escort one of the blocks from the stack upwards, sneaking up behind and using the weapon on the guards in your path. Take the block all the way up to the top right-most cell and leave it on the button inside.
   6. The door to the adjacent cell to the left should be open. Inside, jump through the hole in the floor.
   7. On the floating platform, use the weapon on both guards. This allows you to safely jump down in between the two guards surrounding the exit door. Press E to exit and win the game!
3. Extra Challenges
   a. There are 21 candies to find around the map. Try to collect them all!
   b. The maximum score is 11. Try to find a way to use the weapon to get rid of all the guards!
   c. Bonus puzzle 1 (top left)
      1. Find the two blocks near the top left of the map. This location is inaccessible before gaining the weapon.
      2. Escort at least one block to the button in the top left hallway of the map.
      3. The door to the adjacent cell in the top left should be open. Enjoy 3 candies!
   d. Bonus puzzle 2 (bottom right)
      1. Find the two blocks referenced in step 2d on the right bottom hallway of the map.
      2. Escort one of the blocks to the button on the far right of the hallway.
      3. The door to your original cell should now be open. Enter your original cell from the ceiling and use the weapon on the guard through the opened door.
      4. With the way now clear to the bottom right cell, enjoy 3 candies!


Cheat Codes:
* Press L: Gain 2 lives
* Press R: Restart the game from the beginning (title screen) (WARNING: Wipes all game progress!)
* Press N: Go to the next room in the hierarchy (title screen -> main level -> win screen -> loss screen)